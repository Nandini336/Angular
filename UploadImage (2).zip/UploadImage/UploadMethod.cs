﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
using System.IO;


namespace UploadImage
{
    public class CRUD
    {
        IDbConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlServerConnString"].ConnectionString);
        string ConnectionString = ConfigurationManager.ConnectionStrings["SqlServerConnString"].ConnectionString;

        public void PostData(string storedProc, params object[] param)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@name",param[0]);
            parameters.Add("@contenttype", param[1]);
            parameters.Add("@data", param[2]);          

            db.Query(storedProc, parameters, commandType: CommandType.StoredProcedure);


        }

        public void DeleteData(string storedProc, params object[] param)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@name", param[0]);
            db.Query(storedProc, parameters, commandType: CommandType.StoredProcedure);
        }

        public string InsertUserProfilePics(string conn, UserPics userPics)
        {

            string msg = string.Empty;
           
            var para = new DynamicParameters();
            var outPut = new DynamicParameters();
            try
            {
                para.Add("@name", userPics.PicName);               
               var result = ExecuteSpReturnMessage("uspInsertImages2", para, null, true, null);
                msg = "Image inserted successfully";

            }
            catch (Exception exp)
            {
                msg = "Error :" + exp.Message;
            }
           
            //int valueout = para.Get<int>("@outresult");
            return msg ;
        }

        public IEnumerable ExecuteSpReturnMessage(string storedProcedure, dynamic param = null,
         SqlTransaction transaction = null,

         bool buffered = true, int? commandTimeout = null)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            var returnMessage = connection.Query(storedProcedure, param: (object)param, transaction: transaction, buffered: buffered, commandTimeout: commandTimeout, commandType: CommandType.StoredProcedure);
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
            return returnMessage;
        }


    }
}