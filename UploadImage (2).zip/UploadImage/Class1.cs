﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UploadImage
{   
    public interface IService
    {
        void Serve();
    }
    public class Service1 
    {
        public void Serve() { Console.WriteLine("Service1 Called"); }
    }
    public class Service2 
    {
        public void Serve() { Console.WriteLine("Service2 Called"); }
    }
    public class Client
    {
        private IService _service;
        public Client(IService service)
        {
            this._service = service;
        }
      //  public ServeMethod() { this._service.Serve(); }
    }
}