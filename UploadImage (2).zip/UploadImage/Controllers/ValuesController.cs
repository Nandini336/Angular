﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Web.Http.Cors;
using System.Web;
using System.IO;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;



namespace UploadImage.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]   
    public class ValuesController : ApiController
    {
        string connString = ConfigurationManager.ConnectionStrings["AzureConnString"].ConnectionString;

        [HttpGet]
        [Route("~/api/Values/GetPhotoData")]
        public List<string> GetPhotoData()
        {
            List<string> blobImageContent = GetPhotoURI();
            return blobImageContent;
        }

        public List<string> GetPhotoURI()
        {
           // var userName = "amit@gmail.com";           
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connString);           
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();            
            CloudBlobContainer container = blobClient.GetContainerReference("azurecontainer443");
            var list = container.ListBlobs().OfType<CloudBlockBlob>().ToList();
            List<CloudBlockBlob> blobNames = new List<CloudBlockBlob>();
            //foreach (var item in list)
            //{
            //    if (item.Uri.ToString().Contains(userName))
            //    {
            //        blobNames.Add(item);
            //    }               

            //}
            var listOfBlobURI = new List<string>();
            foreach (var blob in list)
            {
                var blobFileName = blob.Uri.Segments.Last();
                CloudBlockBlob blobReference = container.GetBlockBlobReference(blobFileName);
                string datauri = blobReference.Uri.ToString();
                listOfBlobURI.Add(datauri);
            }
            return listOfBlobURI;
        }

        [HttpPost]
        [Route("~/api/Values/UploadPhotoData")]
        public HttpResponseMessage PhotoUploadData()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            string imagName = null;
            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count > 0)
            {
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files["Image"];                    
                    imagName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());
                    var filePath = HttpContext.Current.Server.MapPath("~/Images/" + postedFile.FileName);
                    postedFile.SaveAs(filePath);                    
                }
            }
          
            string localFolder = ConfigurationManager.AppSettings["sourceFolder"];
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(connString);
            CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference("azurecontainer443");
            cloudBlobContainer.CreateIfNotExists();           

            string[] fileEntries = Directory.GetFiles(localFolder);
            foreach (var item in fileEntries)
            {
                string key = Path.GetFileName(item);
                CloudBlockBlob blob = cloudBlobContainer.GetBlockBlobReference(key);
                using (var fs = System.IO.File.Open(item, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    blob.UploadFromStream(fs);

                }
            }

            return response;

        }

        [HttpPost]
        [Route("~/api/Values/DeletePhotoData")]
        public string DeleteFile(string image)
        {
            string message= DeletePhotoURI(image);
            return message;
        }

        public string DeletePhotoURI(string imageName)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("azurecontainer443");
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(imageName);
            var result = blockBlob.DeleteIfExists();
            string message = "Successfully deleted";
            return message;
        }

        //[HttpPost]
        //[Route("~/api/Values/UploadJsonFile")]
        //public HttpResponseMessage UploadJsonFile()
        //{

        //    HttpResponseMessage response = new HttpResponseMessage();
        //    string imagName = null;
        //    var httpRequest = HttpContext.Current.Request;

        //    if (httpRequest.Files.Count > 0)
        //    {
        //        foreach (string file in httpRequest.Files)
        //        {
        //           var postedFile = httpRequest.Files["Image"];
        //           imagName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());                   
        //           var filePath = HttpContext.Current.Server.MapPath("~/Images/" + postedFile.FileName);                    
        //           postedFile.SaveAs(filePath);
        //        }
        //    }
        //    return response;

            
        //}


      
    }
}
