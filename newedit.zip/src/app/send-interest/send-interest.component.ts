import { AuthService } from './../services/auth.service';
import { Component, OnInit, Inject } from '@angular/core';
import { HeaderMenuComponent } from '../header/header.component';
import { Router, ActivatedRoute } from "@angular/router";
import { dataService } from "../services/data.service";
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-send-interest',
  templateUrl: './send-interest.component.html',
  styleUrls: ['./send-interest.component.css']
})
export class SendInterestComponent implements OnInit {

  constructor(
    private authService: AuthService, 
              private router: Router, 
              private dataservice: dataService, 
              private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public userIdFromHome: any,
    private dialogRef: MatDialogRef<SendInterestComponent>
  ){}
  ngOnInit() {
    let profileId = this.userIdFromHome.responderId;
  }

}
