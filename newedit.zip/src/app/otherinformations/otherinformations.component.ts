import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otherinformations',
  templateUrl: './otherinformations.component.html'
})
export class OtherinformationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
