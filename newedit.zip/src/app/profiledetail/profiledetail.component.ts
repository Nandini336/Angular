import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
import { AuthService } from '../services/auth.service';
declare var $:any;

@Component({
  selector: 'app-profiledetail',
  templateUrl: './profiledetail.component.html',
  styleUrls: ['./profiledetail.component.css']
})
export class ProfiledetailComponent implements OnInit {

  constructor(private http:HttpClient,private authService: AuthService) { }
  myData:any;
  ngOnInit() {

    this.http.get('https://webapiangular.azurewebsites.net/api/Registration/GetProfilesByEmailId?emailid='+ this.authService.currentUser.name)
    .subscribe(
     data => {
       this.myData = data;
     }
     );

    $(document).ready(function() {
      
      var $btnSets = $('#responsive'),
      $btnLinks = $btnSets.find('a');
   
      $btnLinks.click(function(e) {
          e.preventDefault();
          $(this).siblings('a.active').removeClass("active");
          $(this).addClass("active");
          var index = $(this).index();
          $("div.user-menu>div.user-menu-content").removeClass("active");
          $("div.user-menu>div.user-menu-content").eq(index).addClass("active");
      });

      // $("[rel='tooltip']").tooltip();    
 
    $('.view').hover(
        function(){
            $(this).find('.caption').slideDown(250); //.fadeIn(250)
        },
        function(){
            $(this).find('.caption').slideUp(250); //.fadeOut(205)
        }
    ); 

    $('#b1').on('click', function () {
      $('#b2').removeClass('clicked');
      $('#b3').removeClass('clicked');
      $('#b4').removeClass('clicked');
      $(this).addClass('clicked');
      $('.square').addClass('squareBackground');
      $('.binfo').addClass('borderClass');
    
     
 });
 $('#b2').on('click', function () {
  $('#b1').removeClass('clicked');
  $('#b3').removeClass('clicked');
  $('#b4').removeClass('clicked');
  $(this).addClass('clicked');
  $('.square').addClass('squareBackground');
  $('.pinfo').addClass('borderClass');
});

$('#b3').on('click', function () {
  $('#b2').removeClass('clicked');
  $('#b1').removeClass('clicked');
  $('#b4').removeClass('clicked');
  $(this).addClass('clicked');
  $('.square').addClass('squareBackground');
  $('.oinfo').addClass('borderClass');
});

$('#b4').on('click', function () {
  $('#b2').removeClass('clicked');
  $('#b3').removeClass('clicked');
  $('#b1').removeClass('clicked');
  $(this).addClass('clicked');
  $('.square').addClass('squareBackground');
  $('.hinfo').addClass('borderClass');
});
  });
  }

}
